USE [SpecificationsTesting]
GO

INSERT INTO [dbo].[CatTypes]
           ([Description])
     VALUES
           ('N.V.T.')
GO



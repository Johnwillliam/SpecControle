USE [SpecificationsTesting]
GO

INSERT INTO [dbo].[TemperatureClasses]
           ([Description])
     VALUES
           ('No indication'),
('N.V.T.'),
('T3'),
('T4'),
('T5'),
('T6'),
('T 125�C')
GO



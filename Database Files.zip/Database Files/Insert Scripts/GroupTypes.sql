USE [SpecificationsTesting]
GO

INSERT INTO [dbo].[GroupTypes]
           ([Description])
     VALUES
           ('EEx'),
('EEx e II'),
('IIB'),
('IIC'),
('N.V.T.')
GO



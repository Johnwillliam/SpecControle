USE [SpecificationsTesting]
GO

INSERT INTO [dbo].[VentilatorTypes]
           ([Description])
     VALUES
           ('No Indication'),
('Centrifugal fans direct driven'),
('Axial fan direct driven'),
('Thrust fan'),
('Centrifugal fan V-belt driven'),
('Axial fan V-belt driven')
GO



USE [SpecificationsTesting]
GO

INSERT INTO [dbo].[SoundLevelTypes]
           ([Description]
           ,[UOM])
     VALUES
           ('No indication', ''),
('Sound power', 'dB'),
('Sound level at 1.5 m', 'dB(A)'),
('Sound power', 'dB(A)')
GO



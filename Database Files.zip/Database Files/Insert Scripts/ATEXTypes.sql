USE [SpecificationsTesting]
GO

INSERT INTO [dbo].[ATEXTypes]
           ([Description])
     VALUES
('N.V.T.'),
('II 2 G'),
('II 2 G'),
('II 2 GD'),
('II 3 D'),
('II 3 G'),
('N.A.'),
('Ex II 3/3G Ex h IIB+H2 T4 Gc/Gc'),
('Ex II 2/2G Ex h IIB+H2 T4 Gb/Gb'),
('Ex II 2/2G Ex h IIB+H2 T3 Gb/Gb'),
('Ex II 2/2G Ex h IIB T3 Gb/Gb')
GO



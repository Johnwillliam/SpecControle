USE [SpecificationsTesting]
GO

INSERT INTO [dbo].[Users]
           ([Name])
     VALUES
           ('Admin')
GO


